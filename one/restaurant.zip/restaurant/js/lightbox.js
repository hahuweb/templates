$(function () {

    /*
     * menu lightbox
     */
    $('.menu-gallery img').on('click', function () {
        var src = $(this).attr("src");
        $(".menu-img").attr("src", src);
        $('.overley-menu').fadeIn('slow');
        $('.overley-conten').fadeIn('slow');
    });

    $('.nxtButton').on('click', function (event) {
        $(".overley-conten img").hide();
        var $currentImgSrc = $(".overley-conten img").attr("src");
        var $currentImg = $('.menu-gallery img[src="' + $currentImgSrc + '"]');
        var $nextImg = $($currentImg.closest(".mn-img").next().find("img"));
        var $images = $(".menu-gallery img");
        if ($nextImg.length > 0) {
            $(".overley-conten img").attr("src", $nextImg.attr("src")).fadeIn(800);
        } else {
            $(".overley-conten img").attr("src", $($images[0]).attr("src")).fadeIn(800);
        }
        event.stopPropagation();
    });

    $('.prvButton').on('click', function (event) {
        $(".menu-img").hide();
        var $currentImgSrc = $(".menu-img").attr("src");
        var $currentImg = $('.menu-gallery img[src="' + $currentImgSrc + '"]');
        var $nextImg = $($currentImg.closest(".mn-img").prev().find("img"));
        $(".menu-img").attr("src", $nextImg.attr("src")).fadeIn(800);
        event.stopPropagation();
    });

    $('.exitButton').on('click', function () {
        $('.overley-menu').fadeOut('slow');
        $('.overley-conten').fadeOut('slow');
    });
    $('.overley-conten').on('click', function () {
        $('.overley-menu').fadeOut('slow');
        $('.overley-conten').fadeOut('slow');
    });


    if ($(window).width() > 992) {

        /* 
        * img lightbox
        */
        $('.gallery img').on('click', function () {
            var src = $(this).attr("src");
            $(".lb-img").attr("src", src);
            $('.overley').fadeIn('slow');
            $('.overley-content').fadeIn('slow');
        });

        // next
        $('.nextButton').on('click', function (event) {
            $(".overley-content img").hide();
            var $currentImgSrc = $(".overley-content img").attr("src");
            var $currentImg = $('.gallery img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.closest(".img").next().find("img"));
            var $images = $(".gallery img");
            if ($nextImg.length > 0) {
                $(".overley-content img").attr("src", $nextImg.attr("src")).fadeIn(800);
            } else {
                $(".overley-content img").attr("src", $($images[0]).attr("src")).fadeIn(800);
            }
            event.stopPropagation();
        });

        // prev
        $('.prevButton').on('click', function (event) {
            $(".lb-img").hide();
            var $currentImgSrc = $(".lb-img").attr("src");
            var $currentImg = $('.gallery img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.closest(".img").prev().find("img"));
            $(".lb-img").attr("src", $nextImg.attr("src")).fadeIn(800);
            event.stopPropagation();
        });


        // exit
        $('.exitButton').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });
        // overley
        $('.overley-content').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });
    }

    /*
     * vid lightbox 
     */
    
    $('.vid-lb').on('click', function (event) {
        event.preventDefault();
        var src = $(this).attr("href");
        $(".vid-frame").attr("src", src);
        $('.vid-overley').fadeIn('slow');
        $('.video-content').fadeIn('slow');
    });

    // exit
    $('.exitBtn').on('click', function () {
        $('.vid-overley').fadeOut('slow');
        $('.video-content').fadeOut('slow');
        var src = $(this).attr("href");
        $(".vid-frame").attr("src", '');
    });
    // overley
    $('.video-content').on('click', function () {
        $('.vid-overley').fadeOut('slow');
        $('.video-content').fadeOut('slow');
        var src = $(this).attr("href");
        $(".vid-frame").attr("src", '');
    });
})