/* 
 * js
 */


(function ($) {
    "use strict";

    // Initiate the wowjs
    new WOW().init();

    

    //smoothscroll
    $('.navbar-nav a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        $(document).off("scroll");

       
        var target = this.hash,
            menu = target;
        var target = $(this.hash);
        $('html, body').stop().animate({
            scrollTop: (target.offset().top) - 20
        }, 200, 'swing', function () {
            window.location.hash = target;
            $(document).on("scroll", onScroll);
        });
    });

    // add & removing fonts
    $(".navbar-toggler").click(function () {
        $(this).find(".bi").toggleClass("bi bi-list bi bi-x");
    });

    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return true;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });

    // preloader
    $(window).on('load', function () {
        $("#preloader").animate({
            'opacity': '0'
        }, 600, function () {
            setTimeout(function () {
                $("#preloader").css("visibility", "hidden").fadeOut();
            }, 300);
        });

    });

    if ($(window).width() < 992) {

        // navbar-collapse
        $('.collapse, .navbar-nav, .nav-link').click(function () {
            $('.navbar-collapse').collapse('toggle');
            $('.navbar-toggler').find(".bi").toggleClass("bi bi-list bi bi-x");
        });
        
        $(".swiffy-slider").addClass("slider-nav-mousedrag")
        $(".swiffy-slider").removeClass("slider-nav-page")

    } else {


    }
})(jQuery);




