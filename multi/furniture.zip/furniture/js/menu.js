/* 
 * js
 */


(function ($) {
    "use strict";

    // Initiate the wowjs
    new WOW().init();

    // add & removing fonts
    $(".navbar-toggler").click(function () {
        $(this).find(".bi").toggleClass("bi bi-list bi bi-x");
    });

    // preloader
    $(window).on('load', function () {
        $("#preloader").animate({
            'opacity': '0'
        }, 600, function () {
            setTimeout(function () {
                $("#preloader").css("visibility", "hidden").fadeOut();
            }, 300);
        });

    });

    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });

    

    if ($(window).width() < 992) {

        $(".swiffy-slider").removeClass("slider-nav-outside-expand")
        $(".swiffy-slider").addClass("slider-nav-mousedrag")
        $(".swiffy-slider").removeClass("slider-nav-page")

    }

})(jQuery);
