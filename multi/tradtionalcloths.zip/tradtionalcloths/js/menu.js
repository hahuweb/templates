/* 
 * js
 */


(function ($) {
    "use strict";

    // Initiate the wowjs
    new WOW().init();

    // add & removing fonts
    $(".navbar-toggler").click(function () {
        $(this).find(".bi").toggleClass("bi bi-list bi bi-x");
    });

    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });

    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });

    // preloader
    $(window).on('load', function () {
        $("#preloader").animate({
            'opacity': '0'
        }, 600, function () {
            setTimeout(function () {
                $("#preloader").css("visibility", "hidden").fadeOut();
            }, 300);
        });
    });

    // slider
    if ($(window).width() < 992) {

        $(".swiffy-slider").removeClass("slider-nav-outside-expand")
        $(".swiffy-slider").addClass("slider-nav-mousedrag")
        $(".swiffy-slider").removeClass("slider-nav-page")

        $(".dp-toggle").click(function () {
            $(this).find(".bi").toggleClass("bi bi-caret-down-fill bi bi-caret-left-fill");
        });

    } 

})(jQuery);
