/*
 * header
 */

document.write('<nav class="navbar navbar-expand-lg fixed-top">');
document.write(' <div class="container">');

// brand
document.write('<a href="#" class="navbar-brand p-0">የባህል አልባሳት</a>');

// button
document.write('<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">');
document.write('<span class="bi bi-list"></span>');
document.write('</button>');

document.write('<div class="collapse navbar-collapse" id="navbarCollapse">');

// links
document.write('<ul class="navbar-nav ms-auto py-0 pe-4">');
document.write('<li class="nav-item"><a href="index.html" class="nav-link home">መነሻ ገጽ</a></li>');
document.write('<li class="nav-item"><a href="womens.html" class="nav-link womens">የሴቶች</a></li>');
document.write('<li class="nav-item"><a href="mens.html" class="nav-link mens">የወንዶች</a></li>');
document.write('<li class="nav-item"><a href="wedding.html" class="nav-link wedd">የሰርግ</a></li>'); 
document.write('<li class="nav-item dropdown">');
document.write('<a class="nav-link dp-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">ሌሎች <i class="bi bi-caret-down-fill"></i></a>');
document.write('<ul class="dropdown-menu" aria-labelledby="navbarDropdown">');
document.write('<li><a class="dropdown-item kids" href="kids.html">የህጻናት</a></li>');
document.write('<li><hr class="dropdown-divider"></li>');
document.write('<li><a class="dropdown-item shose" href="shose.html">ጫማ</a></li>');
document.write('<li><hr class="dropdown-divider"></li>');
document.write('<li><a class="dropdown-item others" href="others.html">ሌሎች</a></li>');
document.write('</ul>');
document.write('</li>');
document.write('<li class="nav-item"><a href="about.html" class=" nav-link about">ስለእኛ</a></li>'); 
document.write('</ul>');


document.write('</div>');
document.write('</div>');
document.write('</nav>');

