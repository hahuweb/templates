/*
 * header
 */

document.write('<nav class="navbar navbar-expand-lg fixed-top">');
document.write('<div class="container">');
// brand
document.write('<a class="navbar-brand" href="#">ሪልእስቴት</a>');

// button
document.write('<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">');
document.write('<span class="bi bi-list"></span>');
document.write('</button>');

document.write('<div class="container">');
document.write('<div class="navbar-collapse collapse" id="navbarCollapse">');

// menus
document.write('<ul class="navbar-nav ms-auto py-0 pe-4">');
document.write('<li class="nav-item"><a class="nav-link home" href="index.html">መነሻ ገጽ</a></li>');
document.write('<li class="nav-item"><a class="nav-link vill" href="vila.html">ቪላ</a></li>');
document.write('<li class="nav-item"><a class="nav-link gplus" href="gplus.html">ጂ+</a></li>');
document.write('<li class="nav-item"><a class="nav-link apartama" href="apartama.html">አፓርታማ</a></li>');
document.write('<li class="nav-item"><a class="nav-link about" href="about.html">ስለ እኛ</a></li>');
document.write('</ul>');

// closed tags
document.write('</div>');
document.write('</div>');
document.write('</div>');
document.write('</nav>');



