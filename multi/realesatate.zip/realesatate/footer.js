/*
 * header
 */

document.write('<div class="container-fluid footer bg-light border-top pt-4 mt-4">');
document.write('<div class="container">');

document.write('<div class="row g-4">');

// address
document.write('<div class="col-lg-4 col-md-4 col-sm-12">');
document.write('<h4 class="mb-4">መገኛ</h4>');
document.write('<p class="mb-2"><i class="fas fa-map-marker-alt"></i> ልዩ ቦታ ...</p>');
document.write('</div>');

// social media
document.write('<div class="col-lg-4 col-md-4 col-sm-12">');
document.write('<h4 class="mb-4">ማህበራዊ ሚዲያ</h4>');
document.write('<div class="d-flex pt-2">');
document.write('<a class="btn btn-social" href="#"><i class="fab fa-facebook"></i></a>');
document.write('<a class="btn btn-social" href="#"><i class="fab fa-twitter"></i></a>');
document.write('<a class="btn btn-social" href="#"><i class="fab fa-youtube"></i></a>');
document.write('</div>');
document.write('</div>');

// phone
document.write('<div class="col-lg-4 col-md-4 col-sm-12">');
document.write('<h4 class="mb-4">ስልክ</h4>');
document.write('<p class="mb-2"><i class="fas fa-phone-alt"></i> +012 345 67890</p>');
document.write('<p class="mb-2"><i class="fas fa-phone-alt"></i> +012 345 67890</p>');
document.write('<p class="mb-2"><i class="fas fa-phone-alt"></i> +012 345 67890</p>');
document.write('<br />');
document.write('<p class="mb-2"><i class="bi bi-envelope"> </i>info@example.com</p>');
document.write('</div>');
document.write('</div>');

// end container
document.write('</div>');

// copyright
document.write('<div class="container border-top text-center py-4">');
document.write('<p> ኮፒ ራይት © ሪልእስቴት</p>');
document.write('</div>');

// end footer
document.write('</div>');

// back-to-top
document.write('<a href="#" class="btn btn-md  back-to-top"><i class="bi bi-arrow-up"></i></a>');





