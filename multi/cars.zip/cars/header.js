/*
 * header
 */

document.write('<nav class="navbar navbar-expand-lg fixed-top">');
document.write('<div class="container">');

// brand
document.write('<a href="#" class="navbar-brand">መኪና</a>');

// button
document.write('<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">');
document.write('<span class="bi bi-list"></span>');
document.write('</button>');

document.write('<div class="collapse navbar-collapse" id="navbarCollapse">');

// links
document.write('<ul class="navbar-nav ms-auto mb-lg-0">');
document.write('<li class="nav-item"><a href="index.html" class="nav-link home">መነሻ ገጽ</a></li> ');
document.write(' <li class="nav-item"><a href="auto.html" class="nav-item nav-link auto">የቤት</a></li>');
document.write('<li class="nav-item"><a href="suv.html" class="nav-item nav-link suv">ኤስዩቪ</a></li>');
document.write('<li class="nav-item"><a href="pickup.html" class="nav-item nav-link pickup">ፒክአፕ</a></li>');
document.write('<li class="nav-item"><a href="work.html" class="nav-item nav-link work">የስራ</a></li>');
document.write('<li class="nav-item"><a href="about.html" class="nav-item nav-link about">ስለእኛ</a></li> ');
document.write('</ul>');


document.write('</div>');
document.write('</div>');
document.write('</nav>');

