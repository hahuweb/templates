$(function () {

    /*
     * img lightbox
     */
    if ($(window).width() > 992) {

        // img
        $('.gallery img').on('click', function () {
            var src = $(this).attr("src");
            $(".lb-img").attr("src", src);
            $('.overley').fadeIn('slow');
            $('.overley-content').fadeIn('slow');
        });

        $('.nextButton').on('click', function (event) {
            $(".overley-content img").hide();
            var $currentImgSrc = $(".overley-content img").attr("src");
            var $currentImg = $('.gallery img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.closest(".img").next().find("img"));
            var $images = $(".gallery img");
            if ($nextImg.length > 0) {
                $(".overley-content img").attr("src", $nextImg.attr("src")).fadeIn(800);
            } else {
                $(".overley-content img").attr("src", $($images[0]).attr("src")).fadeIn(800);
            }
            event.stopPropagation();
        });
        $('.prevButton').on('click', function (event) {
            $(".lb-img").hide();
            var $currentImgSrc = $(".lb-img").attr("src");
            var $currentImg = $('.gallery img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.closest(".img").prev().find("img"));
            $(".lb-img").attr("src", $nextImg.attr("src")).fadeIn(800);
            event.stopPropagation();
        });


        $('.exitButton').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });
        $('.overley-content').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });

        // full img
        $('.gallery-full img').on('click', function () {
            var src = $(this).attr("src");
            $(".fl-img").attr("src", src);
            $('.overley').fadeIn('slow');
            $('.overley-content').fadeIn('slow');
        });
        // next
        $('.nxtButton').on('click', function (event) {
            $(".overley-content img").hide();
            var $currentImgSrc = $(".overley-content img").attr("src");
            var $currentImg = $('.gallery-full img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.next("img"));
            var $images = $(".gallery-full img");
            if ($nextImg.length > 0) {
                $(".overley-content img").attr("src", $nextImg.attr("src")).fadeIn(800);
            } else {
                $(".overley-content img").attr("src", $($images[0]).attr("src")).fadeIn(800);
            }
            event.stopPropagation();
        });

        // prev
        $('.prvButton').on('click', function (event) {
            $(".fl-img").hide();
            var $currentImgSrc = $(".fl-img").attr("src");
            var $currentImg = $('.gallery-full img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.prev("img"));
            $(".fl-img").attr("src", $nextImg.attr("src")).fadeIn(800);
            event.stopPropagation();
        });

        // exit
        $('.exitButton').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });

        // overley
        $('.overley-content').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });

        /*
         * menu lightbox
         */
        $('.gallery-menu img').on('click', function () {
            var src = $(this).attr("src");
            $(".mn-img").attr("src", src);
            $('.overley').fadeIn('slow');
            $('.overley-content').fadeIn('slow');
        });
        // next
        $('.nxButton').on('click', function (event) {
            $(".overley-content img").hide();
            var $currentImgSrc = $(".overley-content img").attr("src");
            var $currentImg = $('.gallery-menu img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.closest(".img").next().find("img"));
            var $images = $(".gallery-menu img");
            if ($nextImg.length > 0) {
                $(".overley-content img").attr("src", $nextImg.attr("src")).fadeIn(800);
            } else {
                $(".overley-content img").attr("src", $($images[0]).attr("src")).fadeIn(800);
            }
            event.stopPropagation();
        });

        // prev
        $('.prButton').on('click', function (event) {
            $(".mn-img").hide();
            var $currentImgSrc = $(".mn-img").attr("src");
            var $currentImg = $('.gallery-menu img[src="' + $currentImgSrc + '"]');
            var $nextImg = $($currentImg.closest(".img").prev().find("img"));
            $(".mn-img").attr("src", $nextImg.attr("src")).fadeIn(800);
            event.stopPropagation();
        });

        // exit
        $('.exitButton').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });

        // overley
        $('.overley-content').on('click', function () {
            $('.overley').fadeOut('slow');
            $('.overley-content').fadeOut('slow');
        });
    }


    /*
    * vid lightbox
    */

    $('.vid-lb').on('click', function (event) {
        event.preventDefault();
        var src = $(this).attr("href");
        $(".vid-frame").attr("src", src);
        $('.vid-overley').fadeIn('slow');
        $('.video-content').fadeIn('slow');
    });

    // exit
    $('.exitBtn').on('click', function () {
        $('.vid-overley').fadeOut('slow');
        $('.video-content').fadeOut('slow');
        var src = $(this).attr("href");
        $(".vid-frame").attr("src", '');
    });
    // overley
    $('.video-content').on('click', function () {
        $('.vid-overley').fadeOut('slow');
        $('.video-content').fadeOut('slow');
        var src = $(this).attr("href");
        $(".vid-frame").attr("src", '');
    });
})