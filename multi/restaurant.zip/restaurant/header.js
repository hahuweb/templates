/*
 * header
 */

document.write('<nav class="navbar navbar-expand-lg fixed-top">');
document.write('<div class="container">');

// brand
document.write('<a href="#" class="navbar-brand p-0">ሬስቶራንት</a>');

document.write('<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">');
document.write('<span class="bi bi-list"></span>');
document.write('</button>');

document.write('<div class="collapse navbar-collapse" id="navbarCollapse">');

// links
document.write('<ul class="navbar-nav ms-auto py-0 pe-4">');
document.write('<li class="nav-item"><a href="index.html" class="nav-link home">መነሻ ገጽ</a></li> ');
document.write('<li class="nav-item"><a href="about.html" class="nav-link about">ስለእኛ</a></li>');
document.write('<li class="nav-item"><a href="menu.html" class="nav-link menu">ሜኑ</a></li>');
document.write(' <li class="nav-item"><a href="img.html" class="nav-link img">ምስሎች</a></li>');
document.write('</ul>');


document.write('</div>');
document.write('</div>');
document.write('</nav>');

